import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Calculator, TrendingUp, Info, Search, Loader2 } from 'lucide-react'
import './App.css'

function App() {
  const [ticker, setTicker] = useState('')
  const [frontIV, setFrontIV] = useState('')
  const [frontDTE, setFrontDTE] = useState('')
  const [backIV, setBackIV] = useState('')
  const [backDTE, setBackDTE] = useState('')
  const [forwardVol, setForwardVol] = useState(null)
  const [forwardFactor, setForwardFactor] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [lookupInfo, setLookupInfo] = useState(null)

  const lookupTicker = async () => {
    if (!ticker.trim()) {
      setError('Please enter a stock ticker symbol.')
      return
    }

    setLoading(true)
    setError('')
    setLookupInfo(null)

    try {
      const response = await fetch(`/api/options/lookup/${ticker.toUpperCase()}`)
      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to fetch options data.')
        setLoading(false)
        return
      }

      // Populate the form with fetched data
      setFrontIV(data.front_contract.iv.toString())
      setFrontDTE(data.front_contract.dte.toString())
      setBackIV(data.back_contract.iv.toString())
      setBackDTE(data.back_contract.dte.toString())
      
      setLookupInfo({
        ticker: data.ticker,
        frontExp: data.front_contract.expiration,
        backExp: data.back_contract.expiration
      })

      setLoading(false)
    } catch (err) {
      setError('Failed to connect to the API. Please make sure the backend is running.')
      setLoading(false)
    }
  }

  const calculateFF = () => {
    setError('')
    setForwardVol(null)
    setForwardFactor(null)

    // Validate inputs
    const fIV = parseFloat(frontIV)
    const fDTE = parseFloat(frontDTE)
    const bIV = parseFloat(backIV)
    const bDTE = parseFloat(backDTE)

    if (isNaN(fIV) || isNaN(fDTE) || isNaN(bIV) || isNaN(bDTE)) {
      setError('Please enter valid numbers for all fields.')
      return
    }

    if (fIV <= 0 || fDTE <= 0 || bIV <= 0 || bDTE <= 0) {
      setError('All values must be greater than zero.')
      return
    }

    if (fDTE >= bDTE) {
      setError('Back contract DTE must be greater than front contract DTE.')
      return
    }

    // Convert DTE to years
    const T1 = fDTE / 365
    const T2 = bDTE / 365

    // Convert IV to decimal
    const sigma1 = fIV / 100
    const sigma2 = bIV / 100

    // Calculate forward volatility
    const forwardVolSq = ((sigma2 * sigma2 * T2) - (sigma1 * sigma1 * T1)) / (T2 - T1)

    if (forwardVolSq < 0) {
      setError('Invalid calculation: Forward variance is negative. Check your inputs.')
      return
    }

    const fwdVol = Math.sqrt(forwardVolSq)

    // Calculate forward factor
    const ff = (sigma1 - fwdVol) / fwdVol

    // Set results
    setForwardVol((fwdVol * 100).toFixed(2))
    setForwardFactor((ff * 100).toFixed(2))
  }

  const handleReset = () => {
    setTicker('')
    setFrontIV('')
    setFrontDTE('')
    setBackIV('')
    setBackDTE('')
    setForwardVol(null)
    setForwardFactor(null)
    setError('')
    setLookupInfo(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calculator className="w-10 h-10 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">
              Forward Factor Calculator
            </h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Calculate forward volatility and identify mispricing opportunities in options trading
          </p>
        </div>

        {/* Info Card */}
        <Card className="mb-6 border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900 dark:text-blue-100">
              <Info className="w-5 h-5" />
              What is Forward Factor?
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-800 dark:text-blue-200">
            <p className="mb-2">
              The Forward Factor (FF) measures how "hot" near-term volatility is relative to the market's expectation for the subsequent period.
            </p>
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Positive FF:</strong> Near-term volatility is higher than expected (potential overpricing)</li>
              <li><strong>Negative FF:</strong> Near-term volatility is lower than expected (potential underpricing)</li>
            </ul>
          </CardContent>
        </Card>

        {/* Stock Lookup Card */}
        <Card className="mb-6 shadow-xl border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Search className="w-6 h-6" />
              Stock Symbol Lookup
            </CardTitle>
            <CardDescription>Enter a ticker symbol to automatically fetch current options data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <div className="flex-1">
                <Input
                  placeholder="e.g., AAPL, SPY, TSLA"
                  value={ticker}
                  onChange={(e) => setTicker(e.target.value.toUpperCase())}
                  onKeyPress={(e) => e.key === 'Enter' && lookupTicker()}
                  className="text-lg"
                  disabled={loading}
                />
              </div>
              <Button 
                onClick={lookupTicker} 
                disabled={loading || !ticker.trim()}
                className="px-6"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5 mr-2" />
                    Lookup
                  </>
                )}
              </Button>
            </div>
            
            {lookupInfo && (
              <Alert className="mt-4 bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-900">
                <AlertDescription className="text-green-800 dark:text-green-200">
                  ✓ Successfully loaded data for <strong>{lookupInfo.ticker}</strong>
                  <br />
                  Front: {lookupInfo.frontExp} | Back: {lookupInfo.backExp}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Main Calculator Card */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl">Input Parameters</CardTitle>
            <CardDescription>Enter the implied volatility and days to expiration for both contracts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {/* Front Contract */}
              <div className="space-y-4 p-4 rounded-lg bg-muted/50">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Front Contract (Near-term)
                </h3>
                <div className="space-y-2">
                  <Label htmlFor="frontIV">Implied Volatility (%)</Label>
                  <Input
                    id="frontIV"
                    type="number"
                    placeholder="e.g., 20"
                    value={frontIV}
                    onChange={(e) => setFrontIV(e.target.value)}
                    className="text-lg"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frontDTE">Days to Expiration</Label>
                  <Input
                    id="frontDTE"
                    type="number"
                    placeholder="e.g., 30"
                    value={frontDTE}
                    onChange={(e) => setFrontDTE(e.target.value)}
                    className="text-lg"
                  />
                </div>
              </div>

              {/* Back Contract */}
              <div className="space-y-4 p-4 rounded-lg bg-muted/50">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-secondary" />
                  Back Contract (Longer-term)
                </h3>
                <div className="space-y-2">
                  <Label htmlFor="backIV">Implied Volatility (%)</Label>
                  <Input
                    id="backIV"
                    type="number"
                    placeholder="e.g., 18"
                    value={backIV}
                    onChange={(e) => setBackIV(e.target.value)}
                    className="text-lg"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="backDTE">Days to Expiration</Label>
                  <Input
                    id="backDTE"
                    type="number"
                    placeholder="e.g., 60"
                    value={backDTE}
                    onChange={(e) => setBackDTE(e.target.value)}
                    className="text-lg"
                  />
                </div>
              </div>
            </div>

            {/* Error Display */}
            {error && (
              <Alert variant="destructive" className="mt-6">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Buttons */}
            <div className="flex gap-4 mt-6">
              <Button onClick={calculateFF} className="flex-1 text-lg py-6" size="lg">
                <Calculator className="w-5 h-5 mr-2" />
                Calculate
              </Button>
              <Button onClick={handleReset} variant="outline" className="text-lg py-6" size="lg">
                Reset
              </Button>
            </div>

            {/* Results */}
            {forwardVol !== null && forwardFactor !== null && (
              <div className="mt-8 space-y-4">
                <h3 className="text-2xl font-semibold text-center mb-4">Results</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border-green-200 dark:border-green-900">
                    <CardHeader>
                      <CardTitle className="text-green-900 dark:text-green-100">Forward Volatility</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-4xl font-bold text-green-700 dark:text-green-300">{forwardVol}%</p>
                    </CardContent>
                  </Card>
                  <Card className={`bg-gradient-to-br border-2 ${
                    parseFloat(forwardFactor) > 0 
                      ? 'from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30 border-orange-200 dark:border-orange-900'
                      : 'from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 border-blue-200 dark:border-blue-900'
                  }`}>
                    <CardHeader>
                      <CardTitle className={parseFloat(forwardFactor) > 0 ? 'text-orange-900 dark:text-orange-100' : 'text-blue-900 dark:text-blue-100'}>
                        Forward Factor
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className={`text-4xl font-bold ${
                        parseFloat(forwardFactor) > 0 
                          ? 'text-orange-700 dark:text-orange-300'
                          : 'text-blue-700 dark:text-blue-300'
                      }`}>
                        {forwardFactor}%
                      </p>
                      <p className="text-sm mt-2 text-muted-foreground">
                        {parseFloat(forwardFactor) > 0 
                          ? 'Near-term volatility is elevated'
                          : 'Near-term volatility is depressed'}
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>Based on the options trading strategy from Volatility Vibes</p>
          <p className="mt-1">Powered by Polygon.io market data</p>
        </div>
      </div>
    </div>
  )
}

export default App

